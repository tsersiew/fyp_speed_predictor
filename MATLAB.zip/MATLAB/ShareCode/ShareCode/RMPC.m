% clc
clear all
% close all
%%% Robust MPC with SDPR %%%%%%%%%%%%%%%%
cvx_solver MOSEK                               % in this code, we need cvx toolbox and MOSEK solver
H=5;  % Prediction Horizon
l=1;  % Control Horizon
h=15;  % historical time window length
%% Load data           
open('WLTP3.fig');
b = get(gca,'Children');
y= get(b, 'YData');           
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[t_ref_full,v_ref_full] = build_space_domain_fun(y(1,1490+h:1791-H));
delta_s=25;%40S
v_ref=v_ref_full(1:delta_s:end);                % Reference vehicle speed 
v_ref=max(v_ref,6);                             % in spaced domian, velcoity cannot be zero
t_ref=t_ref_full(1:delta_s:end);
N=size(v_ref,2);
t_ref=[t_ref,t_ref(end)*ones(1,H)];
v_ref=[v_ref,v_ref(end)*ones(1,H)];
% mass
m=1500;                                         % mass of the vehicle 1500kg.
E_ref=0.5*m*v_ref.^2;                           % reference kinetic energy
v_fixed=mean(y(1490:1791));%27.7
Delta_E_ref=(0.5*m*v_fixed^2-E_ref);
F_ref=zeros(1,N);
for i=1:size(E_ref,2)-1
    F_ref(i)=E_ref(i+1)-E_ref(i);
end
zeta_ref=1./(sqrt(2.*E_ref./m));
i=[];
E_ref_plan=E_ref;
%% Define vehicle following scenario parameters
%%% air drag poly
air_drag_poly=[5.42869124885574e-15 -3.22818583526412e-12   7.96948040827893e-10    -1.05903506540120e-07   8.22880227855936e-06    -0.000381970346816899   0.0105116528829943  0.221797647960904];
%%% tyre resistance
f_T=0.01;g=9.800;                               %tyre resistance
f_d=0.36;                                       %air drag
F_tyre=m*g*f_T;
%% Define state space relationship matrices
a11=1-2*f_d/m;      
A=[a11 0;0 1];       %you may want to change these matrices
B=[1 0;0 1];

Cf=[1 0;0 1;0 0]; 
Dfu=[0 0;0 0;1 0];   
 
Cz=[1 0;0 1;0 0;0 0]; 
Dzu=[0 0;0 0;1 0;0 1];  

Bc=[1 0;0 1];       
Df_c=[0 0;0 0;0 0];
Dz_c=[0 0;0 0;0 0;0 0];
 
Bd=[1;0];            %disturbance matrix disturbance on velocity difference
Dzd=[0;0;0;0];       %disturbance matrix
Dfd=[0;0;0];         %disturbance matrix
 
 
nx=2;                % number of states
nu=2;                % number of input
nf=3;                % number of signals
nz=4;                % number of costs 
nd=1;                % number of disturbance

A_bar=myAbar(A,H);   % calculate stack matrices
B_bar=myBbar(A,B,H);
Cz_bar=myCbar(A_bar,Cz,Cz,H);
Cf_bar=myCbar(A_bar,Cf,Cf,H);
Dzu_bar=myDbar(B_bar,Cz,Cz,Dzu,H);
Dfu_bar=myDbar(B_bar,Cf,Cf,Dfu,H);


B_d_bar=myBbar(A,Bd,H);
Dz_d_bar=myDbar(B_d_bar,Cz,Cz,Dzd,H);
Df_d_bar=myDbar(B_d_bar,Cf,Cf,Dfd,H);

B_c_bar=myBbar(A,Bc,H);
Dz_c_bar=myDbar(B_c_bar,Cz,Cz,Dz_c,H);
Df_c_bar=myDbar(B_c_bar,Cf,Cf,Df_c,H);
Dznl_bar=Dz_c_bar;
Dfnl_bar=Df_c_bar;
 
Simulation_time=N;
%%%Define initial state
t0=10;
x0=[0;t0];           % initial state
x=x0;
%%%Define constraints ;
v_min=1;
v_max=33;
E_min=0.5*m*v_min^2;
E_max=0.5*m*v_max^2;
%  
a_max=3;
a_min=-3;
%  
Ft_min=0;
Ft_max=a_max*m*delta_s;
Fb_min=a_min*m*delta_s;
Fb_max=0;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
u=zeros(H*nu,1);
z_bar=[];
fl_bar=[];
fu_bar=[];
Constant_bar=[];

N_u=H*nu;N_d=H*nd;N_z=H*nz;N_f=(H+1)*nf;
%%% Define the disturbance boundary of high level disturbance
% dU = d_Vu*ones(N_d,1);   
% dL = d_Vl*ones(N_d,1);
%weighting parameters
P=[0.0007 0 0 0; %0.0005/0.0007
  0 0 0 0;
  0 0 0 0;
  0 0 0 0];
R=[0.0007 0 0 0;
   0 1000 0 0; % terminal weight on time 
   0 0 0 0;
   0 0 0 0];
Q=[kron(eye(H),P),zeros(N_z,nz);
    zeros(nz,N_z),R];
pp=[0.0000 0 0.045 1040000]; %0.045/0.45/0.045
PP=kron(ones(1,H+1),pp);
     
    d_bound=93750;         % fix boundary=0.5*1500*v_w^2*delta_s
    %(it is safe to try any d_bound <183750, if (in case) it's infeasible, try a smaller d_bound) 
%     dv=(2*(rand(1,H+1)-0.5))*d_bound; % generate uniform distributed disturbance
dv = zeros(d_bound,1);
%     plot(dv)
%% Start iterations
tic
for i=1:Simulation_time
    Constant(1,i)=-F_tyre-2*f_d/m*E_ref(i)-F_ref(i);
    Constant(2,i)=-zeta_ref(i);
    for j=0:H-1
        Constant_bar=[Constant_bar;-F_tyre*delta_s-2*f_d/m*E_ref(i+j)-F_ref(i+j);-zeta_ref(i)];
    end
    j=[];
    
%      d_bar=dv;
     d_Vu=max(dv);          % set time-variant disturbance boundaries
     d_Vl=min(dv);
     du = d_Vu*ones(N_d,1);
     dl = d_Vl*ones(N_d,1);

     a=0.000025;
     b=13.439877;%m/s vs J
     delta_t_min=(a*(x(1,i)+E_ref(i))+b-v_ref(i))/abs(a_min)+3;
     delta_t_max=11;
     
     if i>=Simulation_time-H+1
%         P=[0.04 0 0 0;
%           0 0 0 0;
%           0 0 0 0;%0.0045
%           0 0 0 6500];%dv; a;eta
%         R=[0.04 0 0 0;
%            0 1000 0 0;
%            0 0 0 0;
%            0 0 0 6500];
%         Q=[kron(eye(H),P),zeros(N_z,nz);
%             zeros(nz,N_z),R];
%         pp=[0 0 0 6500];
%         PP=kron(ones(1,H+1),pp);
        Delta_E_ref(i:i+H)=0.5*m*v_ref(end)^2-E_ref(i:i+H);
     end
    
%%%%% Start CVX solver %%%%%
     cvx_begin sdp quiet
%      cvx_precision low
     cvx_precision high

%%%  Define variables
     variable gamma_bar;
     variable u(N_u,1);
     variable D(N_d,N_d) diagonal;
     variable Du(N_d,N_d,N_f) diagonal ;
     variable Dl(N_d,N_d,N_f) diagonal ; 
     
    
     for j=0:H   
%          fprintf('i+j = %d \n', i+j);
        fl_bar=[fl_bar;[E_min-E_ref(i+j);delta_t_min;Fb_min]];
        fu_bar=[fu_bar;[E_max-E_ref(i+j);delta_t_max;Ft_max]];
        z_bar=[z_bar;[Delta_E_ref(i+j)+dv(j+1);t0;0;0]]; 
     end
%%%  Define objective functions 
     minimise(gamma_bar);

%%%  Define constraints 
     subject to       % subject to SDPR LMI constraints      
        D>=0;         % LMI 1
        bd=(Dz_d_bar'*Q'*Q*Cz_bar*x0)+(Dz_d_bar'*Q'*Q*Dzu_bar*u)+(Dz_d_bar'*Q'*Q*Dz_c_bar*Constant_bar)-(Dz_d_bar'*Q'*Q*z_bar)+Dz_d_bar'*PP'; %
        cd=(x0'*Cz_bar'*Q'*Q*Cz_bar*x0)+(x0'*Cz_bar'*Q'*Q*Dzu_bar*u)+(u'*Dzu_bar'*Q'*Q*Cz_bar*x0)...
            -(x0'*Cz_bar'*Q'*Q*z_bar)-(z_bar'*Q'*Q*Cz_bar*x0)-(u'*Dzu_bar'*Q'*Q*z_bar)-(z_bar'*Q'*Q*Dzu_bar*u)+(z_bar'*Q'*Q*z_bar)...
            +(x0'*Cz_bar'*Q'*Q*Dz_c_bar*Constant_bar)+(Constant_bar'*Dz_c_bar'*Q'*Q*Cz_bar*x0)...%+(u'*Dzu_bar'*Q'*Q*Dznl_bar*eta_nl)+(eta_nl'*Dznl_bar'*Q'*Q*Dzu_bar*u)+(eta_nl'*Dznl_bar'*Q'*Q*Dznl_bar*eta_nl)
            -(Constant_bar'*Dz_c_bar'*Q'*Q*z_bar)-(z_bar'*Q'*Q*Dz_c_bar*Constant_bar)...
            +PP*(Cz_bar*x0+Dzu_bar*u)+(x0'*Cz_bar'+u'*Dzu_bar')*PP';
        L11=-Dz_d_bar'*Q'*Q*Dz_d_bar+D;
        L12=-D*(du+dl)/2-bd;
        L13=zeros(N_d,N_z+nz);
        L22=dl'*D*du-cd+gamma_bar;
        L23=u'*Dzu_bar'*Q'+Constant_bar'*Dz_c_bar'*Q';
        L=[L11,L12,L13;
           L12',L22, L23;
           L13',L23',eye(N_z+nz)];   
        L>=0;
        alpha_u_bar=[kron(eye(H),eye(nf)),zeros(N_f-nf,nf);zeros(nf,N_f-nf),eye(nf)];
        alpha_l_bar=[kron(eye(H),eye(nf)),zeros(N_f-nf,nf);zeros(nf,N_f-nf),eye(nf)];
       
        for j=1:N_f
            I=eye(N_f);
            Du>=0;      % LMI 2
            Lu11=Du(:,:,j);
            Lu12=-Du(:,:,j)*(du+dl)/2-Df_d_bar'*I(:,j)/2;
            Lu22=-I(j,:)*Cf_bar*x0-I(j,:)*Dfu_bar*u-I(j,:)*Df_c_bar*Constant_bar+dl'*Du(:,:,j)*du+I(j,:)*alpha_u_bar*fu_bar; %
            Lu=[Lu11,Lu12;Lu12',Lu22];
            Lu>=0;
            
            Dl<=0;      % LMI 3
            Ll11=Dl(:,:,j);
            Ll12=-Dl(:,:,j)*(du+dl)/2-Df_d_bar'*I(:,j)/2;
            Ll22=-I(j,:)*Cf_bar*x0-I(j,:)*Dfu_bar*u-I(j,:)*Df_c_bar*Constant_bar+dl'*Dl(:,:,j)*du+I(j,:)*alpha_l_bar*fl_bar; %
            Ll=[Ll11,Ll12;Ll12',Ll22];
            Ll<=0;
        end
        x_bar=A_bar*x0+B_bar*u+B_c_bar*Constant_bar;
        deltaE=x_bar(1:nx:end);
        zeta_min=inv_pos(sqrt(2.*(deltaE+E_ref(i:i+H)')./m));
        zeta=u(2:nu:end);
        0<=zeta-zeta_min; % convex constraint
     cvx_end
%%%%% End CVX solver %%%%%
u1(:,i)=u(1:nu,1);
ego_Ft(:,i)=u(1,1)/delta_s;
ego_zeta(:,i)=u(2,1);
if i>=Simulation_time-5*H
    d(i)=0;
else
    d(i)=0;
end
x(:,i+1)=A*x(:,i)+B*u1(:,i)+Bc*Constant(:,i)+Bd*d(i);
x0=x(:,i+1);
 
z_bar=[];
fl_bar=[];
fu_bar=[];
Constant_bar=[];

%%% store results for further analysis 
store_gamma(i)=gamma_bar;
store_t_min(i)=delta_t_min;
store_t_max(i)=delta_t_max;
store_zeta(i,:)=zeta;
store_zeta_min(i,:)=zeta_min;
store_cvx(i)=cvx_optval;
store_time(i)=cvx_cputime;
E_ego(i)=x(1,i)+E_ref(i);
v(i)=abs(sqrt(2*(E_ego(i))/m));
delta_time(i)=x(2,i);
delta_h(i)=v(i)*delta_time(i);
end;                 % End iterations
toc
%% Plot figures
figure()
v(N+1)=sqrt(2*(x(1,N+1)+E_ref(N+1))/m);
t_ego=x(2,1:N+1)+t_ref(1,1:N+1);
x0=100;
y0=100;
width=1200;
height=640;
set(gcf,'units','points','position',[x0,y0,width,height])
set(0,'defaultTextInterpreter','latex');
set(gca,'LooseInset',get(gca,'TightInset'))
subplot(2,3,1)
% plot(v(1:N+1)) %
% hold on 
% plot(v_ref(1:N+1))
% plot(v_fixed*ones(1,N+1))
% xlabel('distance [m]')
% xlim([0,N+1])
plot(t_ego,v)   % time domain 
hold on 
plot(y(1,1490:1791))
plot(v_fixed*ones(1,round(t_ego(end))))
grid on
xlabel('time [s]')
% xlim([0,round(t_ego(end))+10])
ylabel('velocity [m/s]')
legend('Ego Vehicle Velocity','Lead Vehicle Velocity','Cruise Fixed Velocity')
set(gca,'fontsize',16)

subplot(2,3,2)
for i=1:size(x,2)-1
    full_delta_t(delta_s*(i-1)+1:delta_s*(i))=x(2,i);
    full_t_min(delta_s*(i-1)+1:delta_s*(i))=store_t_min(i);
    full_t_max(delta_s*(i-1)+1:delta_s*(i))=store_t_max(i);
end
% plot(full_delta_t)
% hold on 
% plot(t_ref(1:N))
% plot(full_t_min,'-.')
% plot(full_t_min,'-.')
plot(t_ego,x(2,:))
hold on 
plot(t_ego(1:N),store_t_min)
plot(t_ego(1:N),store_t_max)
grid on
xlabel('time [s]')
ylabel('$\Delta$, t [s]')
ylim([0,12])
legend('delta t','min time','max time')
set(gca,'fontsize',16)

subplot(2,3,3)
for i=1:size(ego_zeta,2)
    full_ego_zeta(delta_s*(i-1)+1:delta_s*(i))=ego_zeta(i);
    full_zeta_min(delta_s*(i-1)+1:delta_s*(i))=store_zeta_min(i);
end
% plot(full_ego_zeta(1:size(t_ref_full,2)),'.')
% hold on 
% plot(full_zeta_min(1:size(t_ref_full,2)),'-')
% plot(store_zeta_min2(1:N),'-.')
plot(t_ego(1:N), ego_zeta)
hold on
plot(t_ego(1:N),store_zeta_min(:,1),'-.')
grid on
xlabel('time [s]')
ylabel('$\zeta$')
% xlim([0,size(t_ref_full,2)])
legend('$\zeta$','$\frac{1}{\sqrt(2E/m)}$','Interpreter','latex')
set(gca,'fontsize',16)

% subplot(2,3,4)
% plot(delta_h(1:N))
% grid on
% xlabel('distance [m]')
% ylabel('headway distance')
% xlim([0,N])
% legend('rough \Delta h')
% set(gca,'fontsize',16)

subplot(2,3,5)
plot(t_ego(1:N),ego_Ft)
hold on 
% plot(t_ego(1:N),ego_Fb/delta_s)
% plot(t_ego(1:N),(ego_Ft+ego_Fb)/delta_s,'-.')
grid on
xlabel('time [s]')
ylabel('traction force')
xlim([0,round(t_ego(end))])
legend('F_{t}')
% legend('F_{t}','F_{b}','Sum Force')
set(gca,'fontsize',16)

% subplot(2,3,6)
% plot(d(1:N))
% grid on
% xlabel('distance [m]')
% ylabel('disturbance on $\Delta$ E [J]')
% xlim([0,N])
% % legend('ego','ref','ref distrubed')
% set(gca,'fontsize',16)
%% Calculate energy consumption 
mf_sum=sum(ego_Ft(1:end))*delta_s
% ct=sum(store_time)
tmax=max(abs(x(2,:)-t0))
% cvx_sum=sum(store_cvx(1:404))
%% validation on zeta: id zeta1
% figure()
% x0=100;
% y0=100;
% width=1200;
% height=640;
% set(gcf,'units','points','position',[x0,y0,width,height])
% set(0,'defaultTextInterpreter','latex');
% set(gca,'LooseInset',get(gca,'TightInset'))
% scale=linspace(1,N+H,N+H);
% for i=1:size(store_zeta,1)
%     delta_zeta(i,:)=store_zeta(i,:)-store_zeta_min(i,:);
%     plot(scale(1,i:i+H-1),delta_zeta(i,:))
% %     plot(scale(1,i:i+H-1),store_zeta(i,:),'.')
% %     plot(scale(1,i:i+H-1),store_zeta_min(i,:),'-')
%     hold on 
% end
% xlabel('Distance, $s$ [m]')
% ylabel('error on $\zeta$')
% legend('error on \zeta')
% % ylabel('$\zeta, \frac{1}{\sqrt(2E/m)}$')
% % legend('$\frac{1}{\sqrt(2E/m)}$','$\zeta$','Interpreter','latex')
% xlim([0,N])
% grid on 
% set(gca,'fontsize',16)
%%
%%Plot check zeta equality is achieved
% figure()
% x0=100;
% y0=100;
% width=1200;
% height=640;
% set(gcf,'units','points','position',[x0,y0,width,height])
% set(0,'defaultTextInterpreter','latex');
% set(gca,'LooseInset',get(gca,'TightInset'))
% scale=linspace(1,N+H,N+H);
% for i=1:size(store_zeta,1)
% %     delta_zeta(i,:)=store_zeta(i,:)-store_zeta_min(i,:);
% %     plot(scale(1,i:i+H-1),delta_zeta(i,:))
%     plot(scale(1,i:i+H-1),store_zeta(i,:),'.')
%     plot(scale(1,i:i+H-1),store_zeta_min(i,:),'-')
%     hold on 
% end
% xlabel('Distance, $s$ [m]')
% % ylabel('error on $\zeta$')
% % legend('error on \zeta')
% ylabel('$\zeta, \frac{1}{\sqrt(2E/m)}$')
% legend('$\frac{1}{\sqrt(2E/m)}$','$\zeta$','Interpreter','latex')
% xlim([0,N])
% grid on 
% set(gca,'fontsize',16)