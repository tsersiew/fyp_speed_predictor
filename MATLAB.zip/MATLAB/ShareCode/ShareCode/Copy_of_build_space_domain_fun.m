function [st, sv, dis_ref] = Copy_of_build_space_domain_fun(v_ref)
%Summary of this function goes here
%   convert velocity profile in time domain into space domain
%   call: [st,sv] = build_space_domain_fun(); in main file
%   input: v vs t profile (no. of timesteps x prediction horizon) 
%   output: v vs s and t vs s profiles;
%   Note: the velocity inported should not contain zero velocity druing the period
%   Note: the velocity is round to integers.
%   creater: Sheng Yu
%   date: 18/09/2021
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
N_timestep = size(v_ref,1)  %476       % Number of data taken from the leading vehicle
N_prediction = size(v_ref,2) %5
dis_ref = zeros(N_timestep, N_prediction);
dis_ref(1,1)=v_ref(1,1);  
for i=1:N_timestep-1
    dis_ref(i+1,1)=dis_ref(i,1)+v_ref(i+1,1);
    for j=1:N_prediction-1
        dis_ref(i,j+1) = dis_ref(i,j) + v_ref(i,j+1);
    end
end
save dis_ref
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% time vs distance
st=zeros(round(dis_ref(end,1)), N_prediction); %476x5
for i=1:size(dis_ref,1) %N_timesteps 
    if dis_ref(i,1)==0 %if actual distance is equal to 0
        for j=1:size(dis_ref,2)
            st(i,j)=st(i,j)+ones(size(st,1),1); %vertical eextension of every column
        end
    else
        for j=1:size(dis_ref,2) %N_predictions 
            st(fix(dis_ref(i,1)),j)=i;
            if i>1 && dis_ref(i,j)~=dis_ref(i-1,j)+1
                s_gap=dis_ref(i,j)-dis_ref(i-1,j);
                interval=1/s_gap;
                for k=dis_ref(i-1,j)+1:dis_ref(i,j)-1  
                    st(fix(k),j)=st(fix(k-1),j)+interval;
                end
            end
        end
    end
end
% figure()
% subplot(2,1,1)
% plot(dis_ref,t_ref,'.')
% hold on
% plot(st(1,:),'--')
% grid on
% legend('time domain','space domain')
% title('time vs distance by time domain and space domain data')
% xlabel('distance [m]')
% ylabel('time [s]')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% space domain 
i=[];
sv=zeros(round(dis_ref(end,1)), N_prediction);
for i=1:size(dis_ref,1) 
    for k=1:size(dis_ref,2)
        sv(fix(dis_ref(i,1)),k)=v_ref(i,k);
    end
end
for j=size(sv,1):-1:1
    for k=1:size(dis_ref,2)
        if sv(j,1)==0
            sv(j,k)=sv(j+1,k);
        end
    end 
end
% subplot(2,1,2)
% plot(dis_ref,v_ref,'.')
% hold on
% plot(sv(1,:))
% grid on
% legend('time domain','space domain')
% title('velocity vs distance by time domain and space domain data')
% xlabel('distance [m]')
% ylabel('velocity [m/s]')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end

