%% LSTM_training.py 
% saves speed_prediction.h5
clear all
close all
x_test = pyrunfile('LSTM_training.py', 'x_test');
y_test = pyrunfile('LSTM_testlabels.py', 'y_test'); 
y = pyrunfile('LSTM_predict.py', 'predictions', x_test=x_test);
y_test = double(y_test);
y_test = transpose(y_test);
y = double(y);
y = [y_test y];
save y