clear all
close all

%% Load data 
load('rural_London_road.mat');

% slope: graident of the road in degree
% v_leg: the combained speed limit (legal limit and speed limit when pass cornering)
% v_ref: practical vehicle velocity (driven by Simos)
% s_axis: the space domain axis.

% convert s_axis from km to m 
s_axis = s_axis.*1000; 

% velocity in space domain
figure; 
plot(s_axis, v_ref); % x y
title('Plot of velocity in space domain');
xlabel('distance (m)');
ylabel('velocity (m/s)');

% velocity in time domain
% t = interp1(v_ref, s_axis);
% figure;
% plot(t)
% t = gradient(sv_plot);
% t = gradient(s_axis, v_ref);
% t = 1./t;
% t = 3./dv; 
t = zeros(1, size(s_axis,2)); 
total_dist = -3;
total_vel = 0;
for i=1:size(s_axis,2)
    total_dist = total_dist + 3;
    total_vel = total_vel + v_ref(i);
    mean_vel = total_vel/i; 
    t(1,i) = total_dist/mean_vel; 
end 
% constant time intervals of 1s
dt = 1:1:t(end); 
v = interp1(t, v_ref, dt, 'spline');
figure; 
plot(v);
title('Plot of velocity in time domain')
xlabel('time (s)');
ylabel('velocity (m/s)')

% derivation of attributes of velocity, acceleration, time 
dV = gradient(v);
dt2 = 1; 
acc = dV./dt2; 

% renaming variables
V_z = transpose(v);
T_z = transpose(dt); 
D_z = transpose(acc); 
save('rural_London_road_time.mat', 'V_z','T_z','D_z')

