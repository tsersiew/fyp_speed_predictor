clear all
close all

%% Load data 
load('rural_London_road.mat');

% slope: graident of the road in degree
% v_leg: the combained speed limit (legal limit and speed limit when pass cornering)
% v_ref: practical vehicle velocity (driven by Simos)
% s_axis: the space domain axis.

% correlation between v_legal and slope 
unused_corr = xcorr(v_legal,slope,'normalized');
figure; 
hold on
yline(0, color='red',LineWidth=1)
plot(unused_corr)
title('Plot of cross-correlation between v_{legal} and slope');
xlabel('samples');
ylabel('R_{xy}');
legend('zero correlation', 'actual correlation');
grid on
hold off 
fprintf('max cross_cor: %d \n',max(unused_corr));
fprintf('min cross_cor: %d \n',min(unused_corr));
fprintf('mean cross_cor: %d \n',mean(unused_corr));

% correlation between v_legal and v_ref
v_corr = xcorr(v_legal,v_ref,'normalized');
figure; 
hold on
yline(0, color='red',LineWidth=1)
plot(v_corr)
title('Plot of cross-correlation between v_{legal} and v_{ref}');
xlabel('samples');
ylabel('R_{xy}');
legend('zero correlation', 'actual correlation');
grid on
hold off 
fprintf('max cross_cor: %d \n',max(v_corr));
fprintf('min cross_cor: %d \n',min(v_corr));
fprintf('means rav	v_legal and slope cross_cor: %d \n',mean(v_corr));

% correlation between slope and v_ref
slope_corr = xcorr(slope,v_ref,'normalized');
figure; 
hold on
yline(0, color='red',LineWidth=1)
plot(slope_corr)
title('Plot of cross-correlation between v_{ref} and slope');
xlabel('samples');
ylabel('R_{xy}');
legend('zero correlation', 'actual correlation');
grid on
hold off 
fprintf('max cross_cor: %d \n',max(slope_corr));
fprintf('min cross_cor: %d \n',min(slope_corr));
fprintf('mean cross_cor: %d \n',mean(slope_corr));