%% Transform reference vehicle data from time domain to space domain 
%% 
clear all 
close all
%%
% Load reference vehicle data in time domain 
folder = './DrivingCycles/DrivingCycles/Europe';
filepattern = fullfile(folder,'*.mat');
matfiles = dir(filepattern);
for i=1:length(matfiles)
    basefilename = fullfile(folder, matfiles(i).name);
    load(basefilename);
    [~,name,ext] = fileparts(matfiles(i).name); 
    figure1 = figure; 
    plot(V_z);
    title(name, 'Interpreter', 'none')
    xlabel('Samples')
    ylabel('V_z', 'Interpreter', 'none')
    figure2 = figure; 
    title(sprintf('Difference in %s', name), 'Interpreter', 'none')
    xlabel('Samples')
    ylabel('diff(V_z)', 'Interpreter', 'none')
    plot(diff(V_z));
    figure3 = figure; 
    findchangepts(diff(V_z), 'MaxNumChanges', 5, 'Statistic', 'rms'); 
    title(sprintf('Difference in %s', name), 'Interpreter', 'none');
    xlabel('Samples')
    ylabel('diff(V_z)', 'Interpreter', 'none')
    g = findchangepts(diff(V_z), 'MaxNumChanges', 5, 'Statistic', 'rms')
    create_new_mat(D_z, T_z, V_z, g, name);
end 
%% function declaration
function [V_z, D_z, T_z] = create_new_mat(D_z, T_z, V_z, g, name)
    diff_V_z_orig = diff(V_z);
    V_z_orig = V_z;
    D_z_orig = D_z; 
    T_z_orig = T_z; 
    V_z = V_z_orig(1:g(1));
    D_z = D_z_orig(1:g(1));
    T_z = T_z_orig(1:g(1));
    diff_V_z = diff_V_z_orig(1:g(1));
    str_saveas = sprintf('%s_%d.%s', name, 0, 'mat');
    if (diff_V_z(round(end/2))~=0)
            save(str_saveas, 'V_z', 'D_z', 'T_z');
    end
    for l=1:length(g)-1
        V_z = V_z_orig(g(l):g(l+1));
        D_z = D_z_orig(g(l):g(l+1));
        T_z = T_z_orig(g(l):g(l+1));
        diff_V_z = diff_V_z_orig(g(l):g(l+1));
        str_saveas = sprintf('%s_%d.%s', name, l, 'mat');
        if (diff_V_z(round(end/2))~=0)
            save(str_saveas, 'V_z', 'D_z', 'T_z');
        end
    end
end 