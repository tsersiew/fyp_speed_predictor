%%
%%
% Load reference vehicle data in time domain 
open('WLTP3.fig')
b = get(gca,'Children');
y= get(b, 'YData');           % the above code is to input reference vehicle speed.
v=y(1,1490:1791);
s=cumtrapz(v);
ds=3; %ds is the sample interval 
s_axis=1:ds:8210; %8210 is the last element in s
v_space=interp1(s,v,s_axis); % velocity in space domain
plot(s_axis, v_space) 